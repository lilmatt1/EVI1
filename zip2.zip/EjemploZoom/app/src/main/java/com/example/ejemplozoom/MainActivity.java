package com.example.ejemplozoom;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private Button buttonAcercar;
    private Button buttonAlejar;
    private float scale=1f;
    private final  float SCALE_STEP=0.1f;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);



        Button buttonProductos = findViewById(R.id.buttonProductos);



        imageView=findViewById(R.id.imageView);
        buttonAcercar=findViewById(R.id.buttonAcercar);
        buttonAlejar=findViewById(R.id.buttonAlejar);



        buttonAcercar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scale+= SCALE_STEP;   //scale=scale+SCALE_STEP;
                imageView.setScaleX(scale);
                imageView.setScaleY(scale);
            }
        });
        buttonAlejar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scale-= SCALE_STEP;
                if (scale>0){
                    imageView.setScaleX(scale);
                    imageView.setScaleY(scale);
                }else{scale+=SCALE_STEP;}
            }
        });

        buttonProductos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


            }
        });




        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}